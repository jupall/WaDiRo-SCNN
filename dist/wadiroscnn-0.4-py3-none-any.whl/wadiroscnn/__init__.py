
from .models import wadiro_scnn
from .models import scnn
from .models import wadiro_linreg
